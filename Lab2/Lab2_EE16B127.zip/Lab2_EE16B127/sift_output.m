function op()
  
  [corresp1, corresp2] = sift_corresp("IMG1.pgm","IMG2.pgm")
  disp(corresp1)
  %disp()
  
end
